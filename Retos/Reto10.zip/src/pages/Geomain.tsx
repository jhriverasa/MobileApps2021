import { useState, useEffect } from "react";
import { Wrapper, Status } from "@googlemaps/react-wrapper";
import { Circle, InfoWindow, Marker } from "@react-google-maps/api";
import { Geolocation } from "@awesome-cordova-plugins/geolocation";
import { locate } from "ionicons/icons";
import axios from "axios";

import {
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
  IonRange,
  IonSelectOption,
  IonItem,
  IonLabel,
  IonButton,
  IonIcon,
  IonSelect,
} from "@ionic/react";
import { RangeValue } from "@ionic/core";

import Map from "../components/Map";

const customFormatter = (value: number) => `${value} Km`;
const predefinedCoordinates = { latitude: 41.881832, longitude: -87.623177 };

const GeoMain = () => {
  const [coordinates, setCordinates] = useState<any>(predefinedCoordinates);
  const [distance, setDistance] = useState(1);
  const [isAreaVisible, setIsAreaVisible] = useState(true);
  const [markets, setMarkets] = useState<any>([]);
  const [selectedMarkerState, setSelectedMarkerState] = useState({
    index: 0,
    isOpen: false,
  });
  const [selectedDay, setSelectedDay] = useState("any");
  const [isSelectingLocation, setSelectinglocation] = useState(false);

  const render = (status: Status) => {
    return <h1>{status}</h1>;
  };

  const geoInstance = Geolocation;

  const getCoordinates = () => {
    geoInstance
      .getCurrentPosition()
      .then((res) => {
        const curLongitude = res.coords.longitude;
        const curLatitude = res.coords.latitude;
        //console.log(long, altit);
        setCordinates({ latitude: curLatitude, longitude: curLongitude });
      })
      .catch((e) => {
        alert(e);
      });

    /*let watch = this.geolocation.watchPosition();
        watch.subscribe((data) => {
      // data can be a set of coordinates, or an error (if an error occurred).
      // data.coords.latitude
      // data.coords.longitude
      */
  };

  useEffect(() => {
    //getCoordinates();
    fetchDataSet();
  }, []);

  useEffect(() => {
    //getCoordinates();
    fetchDataSet();
  }, [distance, coordinates, selectedDay]);

  const handleClickToMap = (e: google.maps.MapMouseEvent) => {
    console.log("clicked map!");

    if (isSelectingLocation) {
      const latLong = e.latLng?.toJSON();
      setCordinates({ latitude: latLong?.lat, longitude: latLong?.lng });
      setSelectinglocation(!isSelectingLocation);
    }
  };

  const fetchDataSet = () => {
    /*Chicago's Farmers Markets bring more than 70 vendors selling fresh fruits, 
    vegetables, plants and flowers to neighborhoods throughout the City of Chicago.
    Markets are held Tuesday, Wednesday, Thursday, Saturday and Sunday around the city. Data Owner: 
    Cultural Affairs and Special Events.*/

    axios
      .get(
        `https://data.cityofchicago.org/resource/atzs-u7pv.json?$where=within_circle(map, ${
          coordinates.latitude
        }, ${coordinates.longitude}, ${distance * 1000})${
          selectedDay === "any" ? "" : `&day=${selectedDay}`
        }`
      )
      .then((response) => {
        setMarkets(response.data);
        console.log(response.data);
      })
      .catch((e) => {
        console.log(e);
      });
  };

  const handleMarkerClick = (e: google.maps.MapMouseEvent, index: number) => {
    setSelectedMarkerState({ index, isOpen: true });
  };

  const onLoad = (infoWindow: google.maps.InfoWindow) => {
    //console.log("infoWindow: ", infoWindow);
  };
  const handleCloseInfoWindow = (i: number) => {
    setSelectedMarkerState({ index: i, isOpen: false });
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Reto 10</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <div className="w-ful h-full">
          {coordinates !== predefinedCoordinates ? (
            <div>
              <div>{`Latitude: ${coordinates.latitude}`}</div>
              <div>{`Longitude: ${coordinates.longitude}`}</div>
            </div>
          ) : (
            <div>Select Position</div>
          )}
          <IonButton
            className="absolute mt-4 ml-56 z-50"
            size="small"
            onClick={() => {
              setIsAreaVisible(!isAreaVisible);
            }}
          >
            Toggle Radius
          </IonButton>
          <IonButton
            size="small"
            className="position absolute z-50"
            style={{ marginTop: 65, marginLeft: 12 }}
            color={isSelectingLocation ? "danger" : "success"}
            onClick={() => {
              setSelectinglocation(!isSelectingLocation);
            }}
          >
            <IonIcon icon={locate}></IonIcon>
          </IonButton>

          <div className="w-full" style={{ height: "65%" }}>
            <Wrapper
              apiKey={"API"}
              render={render}
            >
              <Map
                center={{
                  lat: coordinates.latitude,
                  lng: coordinates.longitude,
                }}
                onClick={handleClickToMap}
                onIdle={() => {
                  console.log("idle");
                }}
                zoom={13}
                style={{ flexGrow: "1", height: "100%" }}
              >
                <Marker
                  position={{
                    lat: coordinates.latitude,
                    lng: coordinates.longitude,
                  }}
                />
                {markets.map((market: any, index: any) => {
                  return (
                    <Marker
                      key={index}
                      position={{
                        lat: parseFloat(market.latitude),
                        lng: parseFloat(market.longitude),
                      }}
                      icon={"./assets/icon/apple.png"}
                      cursor={"pointer"}
                      onClick={(e) => {
                        handleMarkerClick(e, index);
                      }}
                    >
                      {selectedMarkerState.index === index &&
                        selectedMarkerState.isOpen === true && (
                          <InfoWindow
                            onLoad={onLoad}
                            onCloseClick={() => {
                              handleCloseInfoWindow(index);
                            }}
                            position={{
                              lat: parseFloat(market.latitude),
                              lng: parseFloat(market.longitude),
                            }}
                          >
                            <div
                              style={{
                                background: `white`,
                                padding: 15,
                                color: "black",
                              }}
                            >
                              <div>{`Day: ${market.day}`}</div>
                              <div>{`Start Time: ${market.start_time}`}</div>
                              <div>{`End Time: ${market.end_time}`}</div>
                              <div>{`Type: ${market.type}`}</div>
                              <div>{`Location: ${market.location}`}</div>
                            </div>
                          </InfoWindow>
                        )}
                    </Marker>
                  );
                })}

                <Circle
                  visible={isAreaVisible}
                  center={{
                    lat: coordinates.latitude,
                    lng: coordinates.longitude,
                  }}
                  options={{
                    strokeWeight: 3,
                    strokeColor: "#009c4e",
                    fillOpacity: 0.05,
                    zIndex: -50,
                  }}
                  radius={distance * 1000}
                />

                {/*clicks.map((latLng, i) => (
                <Marker key={i} position={latLng} />
                https://react-google-maps-api-docs.netlify.app/#!/Circle
              ))*/}
              </Map>
            </Wrapper>
          </div>

          <IonItem>
            <IonLabel>Select distance (in Kilometers)</IonLabel>
          </IonItem>
          <IonItem>
            <IonRange
              min={0}
              max={10}
              pinFormatter={customFormatter}
              value={distance}
              pin
              onIonChange={(e) => setDistance(e.detail.value as number)}
            ></IonRange>
          </IonItem>
          <IonItem>
            <IonLabel>Day</IonLabel>
            <IonSelect
              value={selectedDay}
              placeholder="Select day"
              onIonChange={(e) => setSelectedDay(e.detail.value!)}
            >
              <IonSelectOption value="any">Any</IonSelectOption>
              <IonSelectOption value="Tuesday">Tuesday</IonSelectOption>
              <IonSelectOption value="Wednesday">Wednesday</IonSelectOption>
              <IonSelectOption value="Thursday">Thursday</IonSelectOption>
              <IonSelectOption value="Saturday">Saturday</IonSelectOption>
              <IonSelectOption value="Sunday">Sunday</IonSelectOption>
            </IonSelect>
          </IonItem>
        </div>
      </IonContent>
    </IonPage>
  );
};

export default GeoMain;
const MarkerTwo: React.FC<google.maps.MarkerOptions> = (options) => {
  const [marker, setMarker] = useState<google.maps.Marker>();

  useEffect(() => {
    if (!marker) {
      setMarker(new google.maps.Marker());
    }

    // remove marker from map on unmount
    return () => {
      if (marker) {
        marker.setMap(null);
      }
    };
  }, [marker]);

  useEffect(() => {
    if (marker) {
      marker.setOptions(options);
    }
  }, [marker, options]);

  return null;
};
