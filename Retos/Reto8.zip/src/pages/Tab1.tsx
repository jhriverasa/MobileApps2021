import { useState, useEffect } from "react";
import { SQLite } from "@awesome-cordova-plugins/sqlite";

import {
  IonButton,
  IonContent,
  IonHeader,
  IonItem,
  IonAlert,
  IonPage,
  IonTitle,
  IonToolbar,
  IonSearchbar,
  IonIcon,
  IonSelect,
  IonSelectOption,
  IonModal,
  IonLabel,
  IonInput,
} from "@ionic/react";

import { add, trash, create } from "ionicons/icons";

import { tableToArray, sqlQueries, companyType } from "../LocalDB";

const emptyCompanyValues = {
  name: "",
  url: "",
  phone: "",
  email: "",
  products: "",
  services: "",
  type: companyType.consulting,
};

const Tab1 = () => {
  const [companies, setCompanies] = useState<any[]>([]);
  const [selectedItem, setSelectedItem] = useState("");
  const [showAlertDelete, setShowAlertDelete] = useState(false);
  const [showModalEdit, setShowModalEdit] = useState(false);
  const [showModalCreate, setShowModalCreate] = useState(false);
  const [filters, setfilters] = useState<{ search: string; type: string }>({
    search: "",
    type: "ANY",
  });
  const [companyValues, setCompanyValues] = useState<{
    name: string;
    url: string;
    phone: string;
    email: string;
    products: string;
    services: string;
    type: string;
  }>(emptyCompanyValues);

  const readAll = () => {
    SQLite.create({ name: "data.db", location: "default" }).then(
      (dbInstance) => {
        dbInstance
          .executeSql(sqlQueries.sqlGetAllCompanies(), [])
          .then((data) => {
            //alert("read all values: " + data);
            setCompanies(tableToArray(data.rows));
          })
          .catch((e) => {
            alert("failed");
          });
      }
    );
  };

  const handleCreateCompany = (
    name: string,
    url: string,
    phone: string,
    email: string,
    products: string,
    services: string,
    type: string
  ) => {
    SQLite.create({ name: "data.db", location: "default" }).then(
      (dbInstance) => {
        dbInstance
          .executeSql(
            sqlQueries.sqlCreateNewCompany(
              name,
              url,
              phone,
              email,
              products,
              services,
              type
            ),
            []
          )
          .then((data) => {
            readAll();
          })
          .catch((e) => {
            alert("failed");
          });
      }
    );
  };

  const handleEditCompany = (
    id: string,
    name: string,
    url: string,
    phone: string,
    email: string,
    products: string,
    services: string,
    type: string
  ) => {
    SQLite.create({ name: "data.db", location: "default" }).then(
      (dbInstance) => {
        dbInstance
          .executeSql(
            sqlQueries.sqlUpdateCompany(
              id,
              name,
              url,
              phone,
              email,
              products,
              services,
              type
            ),
            []
          )
          .then((data) => {
            readAll();
          })
          .catch((e) => {
            alert("failed");
          });
      }
    );
  };

  const handleDeleteCompany = (id: string) => {
    SQLite.create({ name: "data.db", location: "default" }).then(
      (dbInstance) => {
        dbInstance
          .executeSql(sqlQueries.sqlDeleteCompany(id), [])
          .then((data) => {
            readAll();
          })
          .catch((e) => {
            alert("failed");
          });
      }
    );
  };

  useEffect(readAll, []); //read once

  return (
    <IonPage>
      <IonAlert
        isOpen={showAlertDelete}
        onDidDismiss={() => setShowAlertDelete(false)}
        header={"Delete Company"}
        message={"Are you sure?"}
        buttons={[
          {
            text: "Ok",
            handler: (d) => {
              handleDeleteCompany(selectedItem);
              //console.log("deleted: ", selectedItem);
            },
          },
          "Cancel",
        ]}
      />
      <IonModal isOpen={showModalEdit || showModalCreate}>
        <IonContent fullscreen>
          <div className="flex flex-col items-center w-full">
            <IonTitle>
              {showModalCreate ? "Create Company" : "Edit Company"}
            </IonTitle>
            <IonItem className="w-full">
              <IonLabel position="stacked">Name:</IonLabel>
              <IonInput
                value={companyValues.name}
                onIonChange={(e) => {
                  setCompanyValues((prevState) => {
                    return { ...prevState, name: e.detail.value! };
                  });
                }}
              ></IonInput>
            </IonItem>
            <IonItem className="w-full">
              <IonLabel position="stacked">URL</IonLabel>
              <IonInput
                value={companyValues.url}
                onIonChange={(e) => {
                  setCompanyValues((prevState) => {
                    return { ...prevState, url: e.detail.value! };
                  });
                }}
              ></IonInput>
            </IonItem>
            <IonItem className="w-full">
              <IonLabel position="stacked">Phone</IonLabel>
              <IonInput
                value={companyValues.phone}
                onIonChange={(e) => {
                  setCompanyValues((prevState) => {
                    return { ...prevState, phone: e.detail.value! };
                  });
                }}
              ></IonInput>
            </IonItem>
            <IonItem className="w-full">
              <IonLabel position="stacked">E-mail</IonLabel>
              <IonInput
                value={companyValues.email}
                onIonChange={(e) => {
                  setCompanyValues((prevState) => {
                    return { ...prevState, email: e.detail.value! };
                  });
                }}
              ></IonInput>
            </IonItem>
            <IonItem className="w-full">
              <IonLabel position="stacked">Products</IonLabel>
              <IonInput
                value={companyValues.products}
                onIonChange={(e) => {
                  setCompanyValues((prevState) => {
                    return { ...prevState, products: e.detail.value! };
                  });
                }}
              ></IonInput>
            </IonItem>
            <IonItem className="w-full">
              <IonLabel position="stacked">Services</IonLabel>
              <IonInput
                value={companyValues.services}
                onIonChange={(e) => {
                  setCompanyValues((prevState) => {
                    return { ...prevState, services: e.detail.value! };
                  });
                }}
              ></IonInput>
            </IonItem>
            <IonItem className="w-full">
              <IonSelect
                value={companyValues.type}
                defaultChecked
                onIonChange={(e) => {
                  setCompanyValues((prevState) => {
                    return { ...prevState, type: e.detail.value! };
                  });
                }}
              >
                <IonSelectOption value={companyType.consulting}>
                  Consultoria
                </IonSelectOption>
                <IonSelectOption value={companyType.development}>
                  Desarrollo
                </IonSelectOption>
                <IonSelectOption value={companyType.factory}>
                  Fabrica
                </IonSelectOption>
              </IonSelect>
            </IonItem>
            <div className="flex mt-6">
              <IonButton
                onClick={() => {
                  const { name, url, phone, email, products, services, type } =
                    companyValues;

                  if (showModalCreate) {
                    handleCreateCompany(
                      name,
                      url,
                      phone,
                      email,
                      products,
                      services,
                      type
                    );
                    setShowModalCreate(false);
                    //console.log("created: ", selectedItem);
                  }
                  if (showModalEdit) {
                    handleEditCompany(
                      email,
                      name,
                      url,
                      phone,
                      email,
                      products,
                      services,
                      type
                    );
                    setShowModalEdit(false);
                    //console.log("Edit: ", companyValues);
                  }
                  readAll();
                }}
              >
                Accept
              </IonButton>

              <IonButton
                onClick={() => {
                  if (showModalCreate) setShowModalCreate(false);
                  if (showModalEdit) setShowModalEdit(false);
                }}
              >
                Close
              </IonButton>
            </div>
          </div>
        </IonContent>
      </IonModal>

      <IonHeader>
        <IonToolbar>
          <IonTitle>Reto 8</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <div className="mx-5 flex flex-col justify-center">
          <IonSearchbar
            value={filters.search}
            placeholder="Search"
            onIonChange={(e) => {
              setfilters((prevState) => {
                return { ...prevState, search: e.detail.value! };
              });
            }}
          ></IonSearchbar>
          <IonSelect
            value={filters.type}
            defaultChecked
            onIonChange={(e) => {
              setfilters((prevState) => {
                return { ...prevState, type: e.detail.value! };
              });
            }}
          >
            <IonSelectOption value="ANY">Cualquiera</IonSelectOption>
            <IonSelectOption value={companyType.consulting}>
              Consultoria
            </IonSelectOption>
            <IonSelectOption value={companyType.development}>
              Desarrollo
            </IonSelectOption>
            <IonSelectOption value={companyType.factory}>
              Fabrica
            </IonSelectOption>
          </IonSelect>
          <h1 className="text-center text-2xl font-bold mt-4">Companies</h1>
          <IonButton
            onClick={() => {
              setCompanyValues(emptyCompanyValues);
              setShowModalCreate(true);
            }}
          >
            Add Company
          </IonButton>
          <div>
            {companies.map((company, index) => {
              //some weird code for filters
              var isHidden = false;
              const isFilteredByName = filters.search !== "";
              const isFilteredByType = filters.type !== "ANY";
              if (
                (isFilteredByName &&
                  !String(company.name).includes(filters.search)) ||
                (isFilteredByType && String(company.type) !== filters.type)
              ) {
                isHidden = true;
              }

              return (
                <div
                  className={`flex flex-col items-center w-full rounded-md border border-gray-500 p-3 my-2 ${
                    isHidden ? "hidden" : ""
                  }`}
                  key={index}
                >
                  <div className="font-bold font italic">{company.name}</div>
                  <div className="flex flex-col justify-start w-full">
                    <div>{`URL: ${company.url}`}</div>
                    <div>{`Phone: ${company.phone}`}</div>
                    <div>{`E-Mail: ${company.email}`}</div>
                    <div>{`Products: ${company.products}`}</div>
                    <div>{`Services: ${company.services}`}</div>
                    <div>{`Type: ${company.type}`}</div>
                  </div>
                  <div>
                    <IonButton
                      onClick={() => {
                        setCompanyValues({
                          name: company.name,
                          url: company.url,
                          phone: company.phone,
                          email: company.email,
                          products: company.products,
                          services: company.services,
                          type: company.type,
                        });
                        setSelectedItem(company.email);
                        setShowModalEdit(true);
                      }}
                    >
                      <IonIcon icon={create}></IonIcon>
                    </IonButton>
                    <IonButton
                      color="danger"
                      onClick={() => {
                        setSelectedItem(company.email);
                        setShowAlertDelete(true);
                      }}
                    >
                      <IonIcon icon={trash}></IonIcon>
                    </IonButton>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </IonContent>
    </IonPage>
  );
};

export default Tab1;
