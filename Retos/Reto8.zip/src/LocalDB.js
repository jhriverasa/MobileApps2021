//import { SQLite, SQLiteObject } from "@awesome-cordova-plugins/sqlite";

import { SQLite } from "@awesome-cordova-plugins/sqlite";

/*
○ Nombre de la empresa
○ URL de la página web
○ Teléfono de contacto
○ Email de contacto
○ Productos y servicios
○ Clasificación de la empresa: consultoría, desarrollo a la medida y/o fábrica de software.
*/

const initializeDB = () => {
  SQLite.create({ name: "data.db", location: "default" })
    .then((dbInstance) => {
      console.log("created DB");
      dbInstance
        .executeSql(
          "CREATE TABLE IF NOT EXISTS COMPANY(" +
            "name VARCHAR(40), url VARCHAR(255), phone VARCHAR(25), email VARCHAR(45), products VARCHAR(255), services VARCHAR(255), type VARCHAR(40))",
          []
        )
        .then(() => {
          console.log("Created Company Table");
        })
        .catch((e) => {
          console.log(e);
        });
    })
    .catch((e) => {
      console.log(e);
    });
};

// http://html5doctor.com/introducing-web-sql-databases/
const tableToArray = (rows) => {
  var arr = [];
  var len = rows.length,
    i;
  for (i = 0; i < len; i++) {
    const { name, url, phone, email, products, services, type } = rows.item(i);
    const obj = { name, url, phone, email, products, services, type };
    arr.push(obj);
  }
  return arr;
};

const sqlCreateNewCompany = (
  name,
  url,
  phone,
  email,
  products,
  services,
  type
) => {
  return (
    "INSERT INTO COMPANY(name,url,phone,email,products,services,type) " +
    `VALUES ("${name}","${url}","${phone}","${email}","${products}", "${services}", "${type}");`
  );
};

const sqlGetAllCompanies = () => {
  return "SELECT * FROM COMPANY";
};

const sqlDeleteCompany = (email) => {
  return `DELETE FROM COMPANY WHERE email = "${email}"`;
};

const sqlUpdateCompany = (
  id, //last email
  name,
  url,
  phone,
  email,
  products,
  services,
  type
) => {
  return `UPDATE COMPANY SET name="${name}", url="${url}", phone="${phone}", email="${email}", products="${products}", services="${services}", type="${type}" WHERE email = "${id}"`;
};

const companyType = {
  consulting: "CONSULTORIA",
  development: "DESARROLLO",
  factory: "FABRICA",
};
/*
const handleCreateCompany = () => {
  SQLite.create({ name: "data.db", location: "default" }).then((dbInstance) => {
    dbInstance
      .executeSql(sqlUpdate, [])
      .then((data) => {
        alert("Company created!");
        readAll();
      })
      .catch((e) => {
        alert("failed");
      });
  });
};

const readAll = () => {
  SQLite.create({ name: "data.db", location: "default" }).then((dbInstance) => {
    dbInstance
      .executeSql(sqlReadAll, [])
      .then((data) => {
        //alert("read all values: " + data);
        setCompanies(tableToArray(data.rows));
      })
      .catch((e) => {
        alert("failed");
      });
  });
};

*/
const sqlQueries = {
  sqlCreateNewCompany,
  sqlDeleteCompany,
  sqlGetAllCompanies,
  sqlUpdateCompany,
};

export { initializeDB, tableToArray, sqlQueries, companyType };
